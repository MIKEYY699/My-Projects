import streamlit as st
import pickle
from nltk.corpus import stopwords
import string
from nltk.stem.porter import PorterStemmer
import nltk

nltk.download("punkt")
nltk.download("punkt_tab")
nltk.download("stopwords")

tfidf = pickle.load(open("tfidf.pkl", "rb"))
model = pickle.load(open("model.pkl", "rb"))

ps = PorterStemmer()

# ── Page config ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Spam Detector",
    page_icon="🛡️",
    layout="centered"
)

# ── Custom CSS ────────────────────────────────────────────────────────────────
st.markdown("""
<style>
/* Background gradient */
.stApp {
    background: linear-gradient(135deg, #0f0c29, #302b63, #24243e);
    color: white;
}

/* Title styling */
h1 {
    text-align: center;
    font-size: 2.8rem !important;
    font-weight: 800 !important;
    background: linear-gradient(90deg, #a78bfa, #60a5fa);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    margin-bottom: 0.2rem !important;
}

/* Subtitle */
.subtitle {
    text-align: center;
    color: #a0aec0;
    font-size: 1rem;
    margin-bottom: 2rem;
}

/* Text area label */
label {
    color: #e2e8f0 !important;
    font-size: 1.5rem !important;
    font-weight: 700 !important;
}

/* Text area box */
textarea {
    background-color: #1e1b4b !important;
    color: #e2e8f0 !important;
    border: 2px solid #4c1d95 !important;
    border-radius: 12px !important;
    font-size: 1rem !important;
}

/* Button */
.stButton > button {
    width: 100%;
    background: linear-gradient(90deg, #7c3aed, #2563eb);
    color: white !important;
    font-size: 1.1rem !important;
    font-weight: 700 !important;
    border: none !important;
    border-radius: 12px !important;
    padding: 0.75rem 2rem !important;
    margin-top: 0.5rem;
    transition: opacity 0.2s;
}
.stButton > button:hover {
    opacity: 0.85;
}

/* Result cards */
.result-spam {
    background: linear-gradient(135deg, #7f1d1d, #991b1b);
    border: 2px solid #ef4444;
    border-radius: 16px;
    padding: 1.5rem;
    text-align: center;
    margin-top: 1.5rem;
}
.result-safe {
    background: linear-gradient(135deg, #064e3b, #065f46);
    border: 2px solid #10b981;
    border-radius: 16px;
    padding: 1.5rem;
    text-align: center;
    margin-top: 1.5rem;
}
.result-icon {
    font-size: 3rem;
    margin-bottom: 0.5rem;
}
.result-title {
    font-size: 1.8rem;
    font-weight: 800;
    margin-bottom: 0.5rem;
}
.result-percent {
    font-size: 1.1rem;
    opacity: 0.9;
    margin-bottom: 0.3rem;
}
.result-msg {
    font-size: 0.95rem;
    opacity: 0.75;
}

/* Progress bar area */
.stProgress > div > div {
    border-radius: 10px;
}

/* Divider */
hr {
    border-color: #4c1d95 !important;
}

/* Footer */
.footer {
    text-align: center;
    color: #6b7280;
    font-size: 0.8rem;
    margin-top: 3rem;
}
</style>
""", unsafe_allow_html=True)


# ── Text transform function ───────────────────────────────────────────────────
def transform(text):
    text = text.lower()
    text = nltk.word_tokenize(text)
    y = []
    for i in text:
        if i.isalnum():
            y.append(i)
    text = y[:]
    y.clear()
    for i in text:
        if i not in stopwords.words("english") and i not in string.punctuation:
            y.append(i)
    text = y[:]
    y.clear()
    for i in text:
        y.append(ps.stem(i))
    return " ".join(y)


# ── UI Layout ─────────────────────────────────────────────────────────────────
st.markdown("<h1>🛡️ Spam Detector</h1>", unsafe_allow_html=True)
st.markdown('<p class="subtitle">AI-powered Email & SMS spam detection</p>', unsafe_allow_html=True)
st.markdown("---")

text_input = st.text_area("📩 Enter your Email or SMS text below:", height=180, placeholder="Paste your message here...")

if st.button("🔍 Analyze Message"):
    if text_input.strip() == "":
        st.warning("⚠️ Please enter some text first!")
    else:
        with st.spinner("Analyzing..."):
            transformed = transform(text_input)
            vectorized = tfidf.transform([transformed])
            prediction = model.predict(vectorized)
            probability = model.predict_proba(vectorized)[0]

            spam_percent = round(probability[1] * 100, 2)
            safe_percent = round(probability[0] * 100, 2)

            if prediction[0] == 1:
                st.markdown(f"""
                <div class="result-spam">
                    <div class="result-icon">🚨</div>
                    <div class="result-title">SPAM DETECTED</div>
                    <div class="result-percent">Spam Confidence: <strong>{spam_percent}%</strong></div>
                    <div class="result-msg">This message is very likely spam. Do not click any links!</div>
                </div>
                """, unsafe_allow_html=True)
                st.markdown("<br>", unsafe_allow_html=True)
                st.markdown(f"**Spam Probability:** {spam_percent}%")
                st.progress(int(spam_percent))
            else:
                st.markdown(f"""
                <div class="result-safe">
                    <div class="result-icon">✅</div>
                    <div class="result-title">NOT SPAM</div>
                    <div class="result-percent">Safe Confidence: <strong>{safe_percent}%</strong></div>
                    <div class="result-msg">This message looks safe and legitimate.</div>
                </div>
                """, unsafe_allow_html=True)
                st.markdown("<br>", unsafe_allow_html=True)
                st.markdown(f"**Safe Probability:** {safe_percent}%")
                st.progress(int(safe_percent))

st.markdown("---")
st.markdown('<p class="footer">Built By Khuzaima Rehman</p>', unsafe_allow_html=True)